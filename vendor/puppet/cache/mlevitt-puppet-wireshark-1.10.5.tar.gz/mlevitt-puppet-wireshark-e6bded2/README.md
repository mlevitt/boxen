# Wireshark Puppet Module for Boxen

Installs [Wireshark](http://www.wireshark.org/)

## Usage

```puppet
include wireshark
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
