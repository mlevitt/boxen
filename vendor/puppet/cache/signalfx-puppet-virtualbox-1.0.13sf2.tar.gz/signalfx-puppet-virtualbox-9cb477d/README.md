# VirtualBox Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-virtualbox.svg?branch=master)](https://travis-ci.org/boxen/puppet-virtualbox)

## Usage

```puppet
include virtualbox
```

## Required Puppet Modules

None.
